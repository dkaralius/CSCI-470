import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

public class MazeSquare
{
  //Constants to represent types of squares
  static public final int WALL = 0;
  static public final int SPACE = 1;
  static public final int PATH = 2;
  
  //Constants that store the dimensions(Length and Width) of a maze square
  static public final int L = 15;
  static public final int W = 15;
  
  //Variables that store row,column, and type of square in maze
  //Also if it has been visited or not
  private int row;
  private int column;
  private int type;
  private boolean visited = false;
  
  //Constructor to initialize variables
  public MazeSquare(int row, int column, int type)
  {
      this.row = row;
      this.column = column;
      this.type = type;
  }
  
  //Called when "Clear solution" is pressed
  //Sets 'visited' to false and if type is PATH, gets changed to SPACE
  public void clearSquare()
  {
     visited = false;
     if(type == 2)
     {
        type = 1; 
     }
  }
  
  //Called by the solution algorithm
  //Sets the 'visited' data member to true
  public void markVisited()
  {
     visited = true;
  }
  
  //Called by the solution algorithm
  //Returns the 'visited' data member
  public boolean getVisited()
  {
     return visited;
  }
  
  //Called by the solution algorithm
  //Returns true if type is wall, else returns false
  public boolean isWall()
  {
      if(type == 0)
      {
         return true; 
      }
      else
      {
         return false; 
      }
  }
  
  //Called by the solution algorithm
  //Set the square's type to PATH, 2
  public void setToPath()
  {
     type = 2; 
  }
  
  //Called for each square as part of drawing the maze.
  //Sets the current drawing color based on the square�s type
  public void drawSquare(Graphics g, int startX, int startY)
  {
     if(type == 0)
     {
        g.setColor(Color.GRAY);
        g.fillRect(startX,startY,W,L);
        g.setColor(Color.BLACK);
        g.drawRect(startX,startY,W,L);
     }
     else if(type == 1)
     {
        g.setColor(Color.WHITE);
        g.fillRect(startX,startY,W,L);
        g.setColor(Color.BLACK);
        g.drawRect(startX,startY,W,L);
        
     }
     else if(type == 2)
     {
        g.setColor(Color.RED);
        g.fillRect(startX,startY,W,L);
        g.setColor(Color.BLACK);
        g.drawRect(startX,startY,W,L);   
     }  
  } 
}